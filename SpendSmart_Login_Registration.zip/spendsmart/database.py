import os, sqlite3
DB_NAME = os.environ.get('DATABASE_PATH', os.path.join(os.path.dirname(__file__), 'expense.db'))
def get_db_connection():
    conn=sqlite3.connect(DB_NAME); conn.row_factory=sqlite3.Row; return conn
def init_db():
    conn=get_db_connection(); c=conn.cursor()
    c.execute('''CREATE TABLE IF NOT EXISTS users (id INTEGER PRIMARY KEY AUTOINCREMENT, username TEXT NOT NULL, email TEXT UNIQUE NOT NULL, password TEXT NOT NULL)''')
    c.execute('''CREATE TABLE IF NOT EXISTS expenses (id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER, date TEXT NOT NULL, category TEXT NOT NULL, description TEXT, amount REAL NOT NULL, is_recurring INTEGER DEFAULT 0)''')
    c.execute('''CREATE TABLE IF NOT EXISTS budgets (id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER, month_year TEXT NOT NULL, amount REAL NOT NULL, UNIQUE(user_id, month_year))''')
    # Migrate existing databases safely
    for table in ('expenses','budgets'):
        cols=[r['name'] for r in c.execute(f'PRAGMA table_info({table})').fetchall()]
        if 'user_id' not in cols: c.execute(f'ALTER TABLE {table} ADD COLUMN user_id INTEGER')
    conn.commit(); conn.close()
