from datetime import datetime
from collections import defaultdict
from database import get_db_connection
from expense_manager import get_budget

def get_dashboard_summary(user_id):
    with get_db_connection() as c:
        total=c.execute('SELECT SUM(amount) FROM expenses WHERE user_id=?',(user_id,)).fetchone()[0] or 0.0
        count=c.execute('SELECT COUNT(*) FROM expenses WHERE user_id=?',(user_id,)).fetchone()[0]
        cats=c.execute('SELECT category,SUM(amount) total FROM expenses WHERE user_id=? GROUP BY category ORDER BY total DESC',(user_id,)).fetchall()
        rows=c.execute('SELECT date,amount FROM expenses WHERE user_id=?',(user_id,)).fetchall()
    category_data=[{'category':r['category'],'total':r['total']} for r in cats]; monthly=defaultdict(float); key=datetime.now().strftime('%Y-%m'); spent=0.0
    for r in rows:
        try:
            dt=datetime.strptime(r['date'],'%Y-%m-%d'); monthly[dt.strftime('%b')]+=r['amount']
            if dt.strftime('%Y-%m')==key: spent+=r['amount']
        except (ValueError,TypeError): pass
    budget=get_budget(user_id,key); pct=min(round(spent/budget*100,1),100) if budget>0 else 0
    insights=[]
    if category_data: insights.append(f"🔥 Your highest spending category is <b>{category_data[0]['category']}</b> with ₹{category_data[0]['total']}.")
    if pct>=90: insights.append('⚠️ Warning: You have used over 90% of your monthly budget!')
    elif pct>0: insights.append(f'✅ You are currently within budget ({pct}% of monthly limit used).')
    else: insights.append('💡 Tip: Start logging your daily transactions to see deeper financial trends.')
    return {'total_expenses':total,'total_transactions':count,'monthly_average':round(total/max(len(monthly),1),2),'category_data':category_data,'monthly_totals':dict(monthly),'current_month_spent':spent,'monthly_budget':budget,'budget_percentage':pct,'current_month_key':key,'insights':insights}
