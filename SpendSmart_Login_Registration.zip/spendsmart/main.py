import csv, io, os
from functools import wraps
from flask import Flask, render_template, request, redirect, url_for, Response, session, flash
from werkzeug.security import generate_password_hash, check_password_hash
from database import init_db, get_db_connection
from expense_manager import add_expense,get_all_expenses,get_expense_by_id,update_expense,delete_expense,get_filtered_expenses,set_budget
from reports import get_dashboard_summary

app=Flask(__name__)
app.secret_key=os.environ.get('SECRET_KEY','change-this-secret-before-production')
init_db()

def login_required(fn):
    @wraps(fn)
    def wrapper(*args,**kwargs):
        if 'user_id' not in session:
            flash('Please log in to continue.','error'); return redirect(url_for('login'))
        return fn(*args,**kwargs)
    return wrapper

@app.route('/')
def index():
    return redirect(url_for('home') if session.get('user_id') else url_for('login'))

@app.route('/register',methods=['GET','POST'])
def register():
    if request.method=='POST':
        username=request.form.get('username','').strip(); email=request.form.get('email','').strip().lower(); password=request.form.get('password',''); confirm=request.form.get('confirm_password','')
        if not username or not email or not password: flash('Please fill in all fields.','error')
        elif len(password)<8: flash('Password must contain at least 8 characters.','error')
        elif password!=confirm: flash('Passwords do not match.','error')
        else:
            try:
                with get_db_connection() as conn: conn.execute('INSERT INTO users(username,email,password) VALUES(?,?,?)',(username,email,generate_password_hash(password)))
                flash('Registration successful. Please log in.','success'); return redirect(url_for('login'))
            except Exception: flash('That email is already registered.','error')
    return render_template('register.html')

@app.route('/login',methods=['GET','POST'])
def login():
    if request.method=='POST':
        email=request.form.get('email','').strip().lower(); password=request.form.get('password','')
        with get_db_connection() as conn: user=conn.execute('SELECT * FROM users WHERE email=?',(email,)).fetchone()
        if user and check_password_hash(user['password'],password):
            session.clear(); session['user_id']=user['id']; session['username']=user['username']; return redirect(url_for('home'))
        flash('Invalid email or password.','error')
    return render_template('login.html')

@app.route('/logout')
def logout():
    session.clear(); flash('You have been logged out.','success'); return redirect(url_for('login'))

@app.route('/dashboard',methods=['GET','POST'])
def home():
    uid=session['user_id']
    if request.method=='POST':
        if 'budget_amount' in request.form:
            month=request.form.get('month_key'); amount=request.form.get('budget_amount')
            if month and amount: set_budget(uid,month,float(amount))
        else:
            date=request.form.get('date'); category=request.form.get('category'); desc=request.form.get('description'); amount=request.form.get('amount'); recurring=1 if request.form.get('is_recurring') else 0
            if date and category and amount: add_expense(uid,date,category,desc,float(amount),recurring)
        return redirect(url_for('home'))
    start=request.args.get('start_date'); end=request.args.get('end_date'); cat=request.args.get('category'); search=request.args.get('search')
    expenses=get_filtered_expenses(uid,start,end,cat,search) if (start or end or search or (cat and cat!='All Categories')) else get_all_expenses(uid,5)
    return render_template('home.html',summary=get_dashboard_summary(uid),expenses=expenses,selected_start=start or '',selected_end=end or '',selected_category=cat or 'All Categories',selected_search=search or '')

@app.route('/edit/<int:expense_id>',methods=['GET','POST'])
@login_required
def edit(expense_id):
    uid=session['user_id']; expense=get_expense_by_id(uid,expense_id)
    if not expense: return redirect(url_for('home'))
    if request.method=='POST':
        update_expense(uid,expense_id,request.form.get('date'),request.form.get('category'),request.form.get('description'),float(request.form.get('amount')),1 if request.form.get('is_recurring') else 0); return redirect(url_for('home'))
    return render_template('edit.html',expense=expense)

@app.route('/delete/<int:expense_id>',methods=['POST'])
@login_required
def delete(expense_id): delete_expense(session['user_id'],expense_id); return redirect(url_for('home'))

@app.route('/reports')
@login_required
def reports():
    uid=session['user_id']; return render_template('reports.html',summary=get_dashboard_summary(uid),expenses=get_all_expenses(uid))

@app.route('/export')
@login_required
def export_csv():
    expenses=get_all_expenses(session['user_id'])
    def generate():
        data=io.StringIO(); writer=csv.writer(data); writer.writerow(['ID','Date','Category','Description','Amount','Is Recurring']); yield data.getvalue(); data.seek(0); data.truncate(0)
        for e in expenses:
            writer.writerow([e['id'],e['date'],e['category'],e['description'],e['amount'],'Yes' if e['is_recurring'] else 'No']); yield data.getvalue(); data.seek(0); data.truncate(0)
    response=Response(generate(),mimetype='text/csv'); response.headers.set('Content-Disposition','attachment',filename='expense_report.csv'); return response

if __name__=='__main__': app.run(debug=True)
