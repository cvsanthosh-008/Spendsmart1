SPENDSMART - LOGIN AND REGISTRATION UPDATE

Run locally:
1. Open this folder in VS Code.
2. Open Terminal in this folder.
3. Run: python -m pip install -r requirements.txt
4. Set a secure Flask secret key before deployment (environment variable SECRET_KEY).
5. Run: python main.py
6. Visit http://127.0.0.1:5000/register to create an account.
7. Log in at http://127.0.0.1:5000/login.

Render:
Build command: pip install -r requirements.txt
Start command: gunicorn main:app
Add environment variable SECRET_KEY with a long random value.
For persistent user/expense data on Render, configure a persistent disk and set DATABASE_PATH to a file path on that disk (for example /var/data/expense.db).

Notes:
- Passwords are stored as Werkzeug password hashes.
- Expense and budget queries are scoped to the logged-in user.
- Existing expenses in a previous database without a user_id are not automatically assigned to a new account.
