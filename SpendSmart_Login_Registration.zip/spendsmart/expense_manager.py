from database import get_db_connection

def add_expense(user_id,date,category,description,amount,is_recurring=0):
    with get_db_connection() as c: c.execute('INSERT INTO expenses(user_id,date,category,description,amount,is_recurring) VALUES(?,?,?,?,?,?)',(user_id,date,category,description,amount,is_recurring))
def get_all_expenses(user_id,limit=None):
    with get_db_connection() as c:
        q='SELECT * FROM expenses WHERE user_id=? ORDER BY date DESC,id DESC'; return c.execute(q+(' LIMIT ?' if limit else ''),(user_id,limit) if limit else (user_id,)).fetchall()
def get_expense_by_id(user_id,eid):
    with get_db_connection() as c: return c.execute('SELECT * FROM expenses WHERE id=? AND user_id=?',(eid,user_id)).fetchone()
def update_expense(user_id,eid,date,category,description,amount,is_recurring=0):
    with get_db_connection() as c: c.execute('UPDATE expenses SET date=?,category=?,description=?,amount=?,is_recurring=? WHERE id=? AND user_id=?',(date,category,description,amount,is_recurring,eid,user_id))
def delete_expense(user_id,eid):
    with get_db_connection() as c: c.execute('DELETE FROM expenses WHERE id=? AND user_id=?',(eid,user_id))
def get_filtered_expenses(user_id,start_date=None,end_date=None,category=None,search=None):
    q='SELECT * FROM expenses WHERE user_id=?'; p=[user_id]
    if start_date: q+=' AND date>=?'; p.append(start_date)
    if end_date: q+=' AND date<=?'; p.append(end_date)
    if category and category!='All Categories': q+=' AND category=?'; p.append(category)
    if search: q+=' AND (description LIKE ? OR category LIKE ?)'; p.extend([f'%{search}%',f'%{search}%'])
    q+=' ORDER BY date DESC,id DESC'
    with get_db_connection() as c: return c.execute(q,p).fetchall()
def set_budget(user_id,month,amount):
    with get_db_connection() as c: c.execute('INSERT INTO budgets(user_id,month_year,amount) VALUES(?,?,?) ON CONFLICT(user_id,month_year) DO UPDATE SET amount=excluded.amount',(user_id,month,amount))
def get_budget(user_id,month):
    with get_db_connection() as c:
        r=c.execute('SELECT amount FROM budgets WHERE user_id=? AND month_year=?',(user_id,month)).fetchone(); return r['amount'] if r else 10000.0
